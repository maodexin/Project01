create procedure pay5(IN num int)
  begin
case num 
when 1 then select '数值是1';
when 2 then select '数值是2';
else select '不是1也不是2';
end case;
end;

