create procedure pay2(IN num int)
  begin 
if num<0 then
select '负数';
elseif num=0 then
select '为零';
elseif num>0 then 
select '正数';
end if;
end;

