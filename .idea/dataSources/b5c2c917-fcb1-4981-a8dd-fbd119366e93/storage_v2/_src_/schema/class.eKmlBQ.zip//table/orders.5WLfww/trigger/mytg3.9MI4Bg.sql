create trigger mytg3
  before INSERT
  on orders
  for each row
  begin
   declare n int default 0;
-- 查询购买商品的库存
  select num into n from product where pid = new.pid;
  if new.num>n then 
  set new.num = n;
  end if;
  update product set num = num-new.num where pid=new.pid;
 end;

