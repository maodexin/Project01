create procedure p1()
  BEGIN   declare id int;
  declare name varchar(20);
  declare age int;
  -- 声明游标
  declare mc
  cursor for select * from student;
  -- 打开游标
  open mc;
  -- 提取结果
  FETCH mc into id,name,age;
  -- 显示获取的结果
  select id,name,age;
  close mc; end;

