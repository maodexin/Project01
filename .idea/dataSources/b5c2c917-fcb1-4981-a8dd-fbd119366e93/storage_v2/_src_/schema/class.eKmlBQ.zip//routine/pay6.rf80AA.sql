create procedure pay6(OUT sum int)
  begin 
declare num int default 0;
set sum = 0;
while num<10 do
set num = num+1;
set num = sum+num;
end while;
end;

