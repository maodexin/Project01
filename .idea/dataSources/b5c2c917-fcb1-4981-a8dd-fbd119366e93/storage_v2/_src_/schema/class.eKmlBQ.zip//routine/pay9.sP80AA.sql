create procedure pay9(OUT sum int)
  begin 
declare num int default 0;
set sum = 0;
loop_sum:loop
set num = num+1;
set sum = sum+num;
if num>=10 then
leave loop_sum;
end if;
end loop loop_sum;
end;

