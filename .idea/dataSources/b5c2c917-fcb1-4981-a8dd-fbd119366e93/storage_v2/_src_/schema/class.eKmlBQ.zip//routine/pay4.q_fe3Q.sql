create procedure pay4(IN num int)
  begin 
case 
when num<0 then
select '负数';
when num=0 then
select '为零';
when num>0 then 
select '正数';
end case;
end;

