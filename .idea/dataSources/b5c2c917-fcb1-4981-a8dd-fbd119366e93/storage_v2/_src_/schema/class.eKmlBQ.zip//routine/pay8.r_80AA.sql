create procedure pay8(OUT sum int)
  begin 
declare num int default 0;
set sum = 0;
repeat
set num = num+1;
set sum = sum+num;
until num>10
end repeat;
end;

