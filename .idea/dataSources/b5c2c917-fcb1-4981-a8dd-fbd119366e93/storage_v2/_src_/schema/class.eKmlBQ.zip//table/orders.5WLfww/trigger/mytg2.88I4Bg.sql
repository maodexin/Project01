create trigger mytg2
  after DELETE
  on orders
  for each row
  begin
   update product set num = num+old.num where pid=old.pid;
end;

